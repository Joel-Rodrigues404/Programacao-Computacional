/*
 * JOGO DE PALAVRAS INFERNAL
 * Compilador: ANSI C (C89)
 *
 * Participantes:
 * Nome: ANA VIT�RIA PINHEIRO GOMES
 * Matr�cula: 571392;
 * Email: anavitoriapinheirogomes29@gmail.com;
 * Nome: DIANA MARIA MELO MATOS
 * Matr�cula: 569948;
 * Email: dianamariamelo09@gmail.com;
 * Nome: JOEL ANDERSSON RODRIGUES
 * Matr�cula: 571518;
 * Email: joelrodrigues@aluno.ufc.br;
 *
 * Processamento do c�digo:
 * - Converte todo o texto para mai�sculas
 * - Converte todo o texto para min�sculas
 * - Invers�o de caixa
 * - Apenas a primeira letra da frase em mai�scula
 * - Primeira Letra de Cada Palavra em Mai�scula, Exceto Conectivos
 * - Mostrar a frase original
 * - Nova palavra / Sair
 */

#include <ctype.h>
#include <locale.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define TAMANHO_MAXIMO 101                /* Tamanho m�ximo da string */
#define NOME_ARQUIVO "texto_original.txt" /* Nome do arquivo para salvar o texto */

/* Lista de conectivos que n�o devem ser capitalizados */
char *conectivos[] = {
    "de", "do", "dos", "da", "das", "a", "as", "o", "os", "ao", "aos",
    "no", "nos", "na", "nas", "em", "por", "e", "sobre", "com", "ate",
    "apos", "contra", "desde", "entre", "para", "sem", "sob", "nem",
    "que", "se", "mas", "ainda", "assim"};

int num_conectivos = sizeof(conectivos) / sizeof(conectivos[0]); /* N�mero de conectivos */

/* Fun��o para salvar o texto original em um arquivo */
void salvarTextoOriginal(const char *texto) {
    FILE *file = fopen(NOME_ARQUIVO, "w");
    if (file != NULL) {
        printf("\nTexto Armanezado com Sucesso!\nTexto>> %s\n", texto);
        fprintf(file, "%s", texto);
        fclose(file);
    } else {
        printf("Erro ao salvar o arquivo.\n");
    }
}

/* Fun��o para carregar o texto original do arquivo */
void carregarTextoOriginal(char *texto) {
    FILE *file = fopen(NOME_ARQUIVO, "r");
    if (file != NULL) {
        fgets(texto, TAMANHO_MAXIMO, file);
        fclose(file);
    } else {
        printf("Erro ao carregar o arquivo.\n");
    }
}

/* Fun��o para limpar o buffer de entrada */
void limparBuffer() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF) {};
}

/* Fun��o para validar a string (somente letras e espa�os s�o permitidos) */
int valida_string(char *texto) {
    int i, cont_letras = 0, cont_caracteres_indesejadas = 0;
    size_t tamanho = strlen(texto);

    for (i = 0; texto[i] != '\0'; i++) {

        if (!isalpha(texto[i]) && texto[i] != ' ' && texto[i] != '\n') {
            cont_caracteres_indesejadas++;
        }
        if (isalpha(texto[i])) {
            cont_letras++;
        }
    }

    if (i == 1 && texto[i] == '\0') {
        printf("ERRO: O texto n�o pode ser vazio!!!\n\n");
        return 0;
    } else if (cont_caracteres_indesejadas > 0) {
        printf("ERRO: N�o deve conter s�mbolos ou n�meros nem letras acentuadas!!\n\n");
        return 0;
    } else if (cont_letras == 0) {
        printf("ERRO: Deve conter pelo menos uma letra!!!\n\n");
        return 0;
    }

    return 1;
}

/* Fun��o para converter todas as letras para mai�sculas */
void paraMaiusculas(char *texto) {
    int i;
    for (i = 0; texto[i]; i++) {
        texto[i] = toupper(texto[i]);
    }
}

/* Fun��o para converter todas as letras para min�sculas */
void paraMinusculas(char *texto) {
    int i;
    for (i = 0; texto[i]; i++) {
        texto[i] = tolower(texto[i]);
    }
}

/* Fun��o para inverter a caixa das letras (mai�sculas para min�sculas e vice-versa) */
void inverterCaixa(char *texto) {
    int i;
    for (i = 0; texto[i]; i++) {
        if (isupper(texto[i]))
            texto[i] = tolower(texto[i]);
        else if (islower(texto[i]))
            texto[i] = toupper(texto[i]);
    }
}

/* Fun��o para capitalizar apenas a primeira letra da frase */
void primeiraLetraMaiuscula(char *texto) {
    int i = 0;
    while (texto[i] == ' ')
        i++;

    if (texto[i] != '\0') {
        texto[i] = toupper(texto[i]);
    }
}

/* Funa��o para capitalizar a primeira letra de cada palavra, exceto conectivos */
void capitalizarPalavras(char *texto) {
    int novoInicio = 1, ehConectivo = 0;
    char palavra[TAMANHO_MAXIMO], resultado[TAMANHO_MAXIMO];
    int i = 0, j = 0, k = 0;

    resultado[0] = '\0';
    while (texto[i] != '\0') {
        if (isalpha(texto[i])) {
            palavra[j++] = tolower(texto[i]);
        } else {
            if (j > 0) {
                palavra[j] = '\0';
                ehConectivo = 0;
                for (k = 0; k < num_conectivos; k++) {
                    if (strcmp(palavra, conectivos[k]) == 0) {
                        ehConectivo = 1;
                        break;
                    }
                }
                if (!ehConectivo || novoInicio) {
                    palavra[0] = toupper(palavra[0]);
                }
                strncat(resultado, palavra, TAMANHO_MAXIMO - strlen(resultado) - 1);
                j = 0;
            }
            strncat(resultado, &texto[i], 1);
            novoInicio = (texto[i] == '.' || texto[i] == '!' || texto[i] == '?');
        }
        i++;
    }

    if (j > 0) {
        palavra[j] = '\0';
        ehConectivo = 0;
        for (k = 0; k < num_conectivos; k++) {
            if (strcmp(palavra, conectivos[k]) == 0) {
                ehConectivo = 1;
                break;
            }
        }
        if (!ehConectivo || novoInicio) {
            palavra[0] = toupper(palavra[0]);
        }
        strncat(resultado, palavra, TAMANHO_MAXIMO - strlen(resultado) - 1);
    }

    strncpy(texto, resultado, TAMANHO_MAXIMO - 1);
    texto[TAMANHO_MAXIMO - 1] = '\0';
}

/* Fun��o para exibir uma anima��o de carregamento */
void visualizacao_texto() {
    int i;

    system("cls");

    for (i = 1; i < 4; i++) {
        printf("%d ...\n", i);
        sleep(1);
    }
    printf("\n\n-=-=-=-=-=-=-=-=-RESULTADO-=-=-=-=-=-=-=-=-=-=\n\n");
}

/* Fun��o principal */
int main() {
    char texto[TAMANHO_MAXIMO];
    char opcao;

    setlocale(LC_ALL, "Portuguese_Brazil.1252");

    do {
        do {
            printf("Digite uma string (at� 100 caracteres):\n");
            printf("Somente letras (n�o acentuadas!) e espa�os s�o permitidos.\n");

            fgets(texto, sizeof(texto), stdin);

            if (strlen(texto) == TAMANHO_MAXIMO - 1) {
                printf("Erro: A string excede o tamanho m�ximo permitido (100 caracteres).\n");
                printf("Ser� truncada para 100 caracteres automaticamente!\n");
                limparBuffer();
                continue;
            }

        } while (valida_string(texto) == 0);

        texto[strcspn(texto, "\n")] = '\0';

        salvarTextoOriginal(texto);

        do {
            printf("\nEscolha uma op��o de convers�o:\n");
            printf("[ 1 ] - TODAS AS LETRAS MAI�SCULAS\n");
            printf("[ 2 ] - todas as letras min�sculas\n");
            printf("[ 3 ] - Invers�o de caixa\n");
            printf("[ 4 ] - Apenas a primeira letra da frase em mai�scula\n");
            printf("[ 5 ] - Primeira Letra de Cada Palavra em Mai�scula, Exceto Conectivos\n");
            printf("[ 6 ] - Mostrar a frase original\n");
            printf("[ 0 ] - Nova palavra / Sair\n");
            printf("Op��o: ");
            scanf(" %c", &opcao);

            limparBuffer();

            carregarTextoOriginal(texto);

            switch (opcao) {
            case '1':
                paraMaiusculas(texto);
                visualizacao_texto();
                printf(">>> %s\n", texto);
                break;
            case '2':
                paraMinusculas(texto);
                visualizacao_texto();
                printf(">>> %s\n", texto);
                break;
            case '3':
                inverterCaixa(texto);
                visualizacao_texto();
                printf(">>> %s\n", texto);
                break;
            case '4':
                primeiraLetraMaiuscula(texto);
                visualizacao_texto();
                printf(">>> %s\n", texto);
                break;
            case '5':
                capitalizarPalavras(texto);
                visualizacao_texto();
                printf(">>> %s\n", texto);
                break;
            case '6':
                carregarTextoOriginal(texto);
                printf("Texto original: %s\n", texto);
                break;
            case '0':
                printf("Saindo...\n");
                break;
            default:
                printf("Op��o inv�lida!\n");
            }
        } while (opcao != '0');

        printf("\nDeseja converter uma nova string? (s/n): ");
        scanf(" %c", &opcao);
        limparBuffer();
    } while (opcao == 's' || opcao == 'S');

    return 0;
}
